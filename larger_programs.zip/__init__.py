from larger_programs.reader import Reader

print("module was sucessfully imported")
