print('executing __main__.py with name {}'.format(__name__))
